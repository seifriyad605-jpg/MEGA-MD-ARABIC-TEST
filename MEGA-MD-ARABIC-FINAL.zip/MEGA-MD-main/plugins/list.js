import config from '../config.js';
import commandHandler from '../lib/commandHandler.js';
import { arabicAliases, arabicCategories } from '../lib/arabicAliases.js';
import path from 'path';
import fs from 'fs';

function formatTime() {
    const now = new Date();
    return now.toLocaleTimeString('ar-EG', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
        timeZone: config.timeZone || 'UTC'
    });
}

export default {
    command: 'menu',
    aliases: ['help', 'commands', 'h', 'list', 'منيو', 'مساعدة', 'اوامر', 'أوامر'],
    category: 'general',
    description: 'القائمة الرئيسية للبوت',
    usage: 'منيو',
    isPrefixless: true,

    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        const imagePath = path.join(process.cwd(), 'assets/thumb.png');

        // Show one command's Arabic help when a command name is supplied.
        if (args.length) {
            const searchTerm = args[0].toLowerCase();
            let cmd = commandHandler.commands.get(searchTerm);

            if (!cmd && commandHandler.aliases.has(searchTerm)) {
                const mainCommand = commandHandler.aliases.get(searchTerm);
                cmd = commandHandler.commands.get(mainCommand);
            }

            if (!cmd) {
                return sock.sendMessage(chatId, {
                    text: `❌ الأمر «${args[0]}» مش موجود.\n\nاكتب «منيو» عشان تشوف كل الأوامر.`,
                    ...channelInfo
                }, { quoted: message });
            }

            const arabicName = cmd.arabicAlias || arabicAliases[cmd.command] || cmd.command;
            const category = arabicCategories[cmd.category] || cmd.category;

            const text = `╭━━━〔 📖 شرح الأمر 〕━━━╮
┃
┃ 🟢 *الأمر:* ${arabicName}
┃ 🔤 *الاسم الأصلي:* ${cmd.command}
┃ 📂 *القسم:* ${category}
┃
┃ 💡 *طريقة الاستخدام:*
┃ ${arabicName}
┃
╰━━━━━━━━━━━━━━━━━━━━
💬 لو عايز تشوف كل الأوامر اكتب: *منيو*`;

            if (fs.existsSync(imagePath)) {
                return sock.sendMessage(chatId, {
                    image: { url: imagePath },
                    caption: text,
                    ...channelInfo
                }, { quoted: message });
            }

            return sock.sendMessage(chatId, { text, ...channelInfo }, { quoted: message });
        }

        let text = `╭━━━〔 🤖 ${config.botName || 'MEGA-MD'} 〕━━━╮
┃ 🇪🇬 *بوت عربي بالكامل*
┃ 👑 المالك: ${config.botOwner || 'غير محدد'}
┃ 🧩 الأوامر: ${commandHandler.commands.size}
┃ ⏰ الوقت: ${formatTime()}
┃
┃ 💡 *طريقة الاستخدام:*
┃ اكتب اسم الأمر مباشرة من غير نقطة
┃ مثال: *ملصق*
┃
╰━━━━━━━━━━━━━━━━━━━━\n\n`;

        for (const [cat, cmds] of commandHandler.categories) {
            const catName = arabicCategories[cat] || cat;
            text += `╭──〔 ${catName} 〕\n`;

            for (const cmdName of cmds) {
                const arabicName = arabicAliases[cmdName] || commandHandler.commands.get(cmdName)?.arabicAlias || cmdName;
                text += `│ • *${arabicName}*\n`;
            }

            text += `╰────────────\n\n`;
        }

        text += `📌 *لشرح أي أمر:*
اكتب: *منيو اسم_الأمر*

مثال:
*منيو ملصق*

🇪🇬 كل الأوامر العربية لها أسماء سهلة، والأوامر القديمة بالإنجليزي ما زالت تعمل.`;

        if (fs.existsSync(imagePath)) {
            await sock.sendMessage(chatId, {
                image: { url: imagePath },
                caption: text,
                ...channelInfo
            }, { quoted: message });
        } else {
            await sock.sendMessage(chatId, { text, ...channelInfo }, { quoted: message });
        }
    }
};
