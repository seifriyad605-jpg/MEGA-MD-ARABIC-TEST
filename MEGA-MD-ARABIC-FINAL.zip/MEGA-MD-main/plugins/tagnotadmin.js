export default {
    command: 'tagnotadmin',
    aliases: ['tagmembers', 'tagnon'],
    category: 'admin',
    description: 'Tag all non-admin members in the group',
    usage: '.tagnotadmin',
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        try {
            const groupMetadata = await sock.groupMetadata(chatId);
            const participants = groupMetadata.participants || [];
            const nonAdmins = participants.filter((p) => !p.admin).map((p) => p.id);
            if (nonAdmins.length === 0) {
                await sock.sendMessage(chatId, {
                    text: 'لا non-admin members to tag.',
                    ...channelInfo
                }, { quoted: message });
                return;
            }
            let text = '🔊 *Hello Everyone:*\n\n';
            nonAdmins.forEach((jid) => {
                text += `@${jid.split('@')[0]}\n`;
            });
            await sock.sendMessage(chatId, {
                text,
                mentions: nonAdmins,
                ...channelInfo
            }, { quoted: message });
        }
        catch (error) {
            console.error('خطأ in tagnotadmin command:', error);
            await sock.sendMessage(chatId, {
                text: 'فشل to tag non-admin members.',
                ...channelInfo
            }, { quoted: message });
        }
    }
};
