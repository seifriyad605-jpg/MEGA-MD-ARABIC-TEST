import axios from 'axios';
const AI_APIS = [
    (q) => `https://mistral.stacktoy.workers.dev/?apikey=Suhail&text=${encodeURIComponent(q)}`,
    (q) => `https://llama.gtech-apiz.workers.dev/?apikey=Suhail&text=${encodeURIComponent(q)}`,
    (q) => `https://mistral.gtech-apiz.workers.dev/?apikey=Suhail&text=${encodeURIComponent(q)}`
];
const askAI = async (query) => {
    for (const apiUrl of AI_APIS) {
        try {
            const { data } = await axios.get(apiUrl(query), { timeout: 15000 });
            const response = data?.data?.response;
            if (response && typeof response === 'string' && response.trim()) {
                return response.trim();
            }
        }
        catch {
            continue;
        }
    }
    throw new خطأ('All AI APIs فشل');
};
export default {
    command: 'mistral',
    aliases: ['ai', 'chat', 'ask'],
    category: 'ai',
    description: 'Ask a question to AI',
    usage: '.mistral <question>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const query = args.join(' ').trim();
        if (!query) {
            return sock.sendMessage(chatId, { text: '🤖 *AI Assistant*\n\nUsage: `.mistral <your question>`\nExample: `.mistral explain quantum physics`' }, { quoted: message });
        }
        try {
            await sock.sendMessage(chatId, { react: { text: '🤖', key: message.key } });
            const answer = await askAI(query);
            await sock.sendMessage(chatId, { text: answer }, { quoted: message });
        }
        catch (error) {
            console.error('AI الأمر خطأ:', error.message);
            await sock.sendMessage(chatId, { text: '❌ فشل to get AI response. Please try again later.' }, { quoted: message });
        }
    }
};
