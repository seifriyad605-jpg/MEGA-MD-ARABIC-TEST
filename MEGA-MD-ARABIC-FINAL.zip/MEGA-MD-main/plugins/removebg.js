import axios from 'axios';
import FormData from 'form-data';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
async function getImageBuffer(message) {
    const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const imageMessage = quoted?.imageMessage || message.message?.imageMessage;
    if (!imageMessage)
        return null;
    const stream = await downloadContentFromMessage(imageMessage, 'image');
    const chunks = [];
    for await (const chunk of stream)
        chunks.push(chunk);
    return Buffer.concat(chunks);
}
export default {
    command: 'removebg',
    aliases: ['rmbg', 'bgremove'],
    category: 'tools',
    description: 'إزالة background from an image',
    usage: '.removebg (reply to image or send image with caption)',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const imageBuffer = await getImageBuffer(message);
            if (!imageBuffer) {
                return await sock.sendMessage(chatId, {
                    text: '📸 *إزالة Background*\n\nUsage:\n' +
                        '• Reply to an image with `.removebg`\n' +
                        '• Send image with caption `.removebg`'
                }, { quoted: message });
            }
            const apiKey = process.env.REMOVEBG_KEY;
            if (!apiKey) {
                return await sock.sendMessage(chatId, {
                    text: '❌ RemoveBG API key not configured.'
                }, { quoted: message });
            }
            const form = new FormData();
            form.append('size', 'auto');
            form.append('image_file', imageBuffer, {
                filename: 'image.jpg',
                contentType: 'image/jpeg'
            });
            const response = await axios.post('https://api.remove.bg/v1.0/removebg', form, {
                headers: { ...form.getHeaders(), 'X-Api-Key': apiKey },
                responseType: 'arraybuffer',
                timeout: 60000
            });
            await sock.sendMessage(chatId, {
                image: response.data,
                caption: '✨ *Background removed successfully*\n\n𝗣𝗢𝗪𝗘𝗥𝗘𝗗 𝗕𝗬 𝗠𝗘𝗚𝗔-𝗠𝗗'
            }, { quoted: message });
        }
        catch (err) {
            console.error('RemoveBG خطأ:', err?.response?.data || err.message);
            let msg = '❌ فشل to remove background.';
            if (err.response?.status === 402)
                msg = '💳 API quota exceeded.';
            else if (err.response?.status === 401)
                msg = '🔑 Invalid API key.';
            else if (err.code === 'ECONNABORTED')
                msg = '⏰ Request timeout. حاول مرة أخرى.';
            await sock.sendMessage(chatId, { text: msg }, { quoted: message });
        }
    }
};
