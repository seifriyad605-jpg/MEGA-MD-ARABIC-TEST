import axios from 'axios';
export default {
    command: 'pair',
    aliases: ['paircode', 'session', 'getsession', 'sessionid'],
    category: 'general',
    description: 'Get session id for MEGA-MD',
    usage: '.pair 92305395XXXX',
    async handler(sock, message, args, context) {
        const { chatId } = context;
        const forwardInfo = {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '120363319098372999@newsletter',
                newsletterName: 'MEGA MD',
                serverMessageId: -1
            }
        };
        const query = args.join('').trim();
        if (!query) {
            return await sock.sendMessage(chatId, {
                text: "❌ *Missing الرقم*\nExample: .pair 92305395XXXX",
                contextInfo: forwardInfo
            }, { quoted: message });
        }
        const number = query.replace(/[^0-9]/g, '');
        if (number.length < 10 || number.length > 15) {
            return await sock.sendMessage(chatId, {
                text: "❌ *Invalid Format*\nPlease provide the number with country code but without + or spaces.",
                contextInfo: forwardInfo
            }, { quoted: message });
        }
        await sock.sendMessage(chatId, {
            text: "⚡ *Requesting code from server...*",
            contextInfo: forwardInfo
        }, { quoted: message });
        try {
            const response = await axios.get(`https://mega-pairing.onrender.com/pair?number=${number}`, {
                timeout: 60000
            });
            if (response.data && response.data.code) {
                const pairingCode = response.data.code;
                if (pairingCode.includes("Unavailable") || pairingCode.includes("خطأ")) {
                    throw new خطأ("Server is busy");
                }
                const successText = `✅ *MEGA-MD PAIRING CODE*\n\n` +
                    `Code: *${pairingCode}*\n\n` +
                    `*How to use:*\n` +
                    `1. Open WhatsApp الإعدادات\n` +
                    `2. Tap 'Linked Devices'\n` +
                    `3. Tap 'الرابط a Device'\n` +
                    `4. Select 'الرابط with phone number instead'\n` +
                    `5. Enter the code above.`;
                await sock.sendMessage(chatId, {
                    text: successText,
                    contextInfo: forwardInfo
                }, { quoted: message });
            }
            else {
                throw new خطأ("Invalid response format");
            }
        }
        catch (error) {
            console.error('Pairing Plugin خطأ:', error.message);
            let errorMsg = "❌ *Pairing فشل*\nReason: ";
            if (error.code === 'ECONNABORTED') {
                errorMsg += "Server timeout. Please try again in 1 minute.";
            }
            else if (error.response?.status === 400) {
                errorMsg += "Invalid phone number format.";
            }
            else {
                errorMsg += "The server is currently offline or busy. حاول مرة أخرى later.";
            }
            await sock.sendMessage(chatId, {
                text: errorMsg,
                contextInfo: forwardInfo
            }, { quoted: message });
        }
    }
};
