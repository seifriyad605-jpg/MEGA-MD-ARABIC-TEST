import moment from 'moment-timezone';
import fs from 'fs';
import path from 'path';
export default {
    command: 'script',
    aliases: ['repo', 'sc'],
    category: 'info',
    description: 'Get information about the MEGA-MD GitHub repository',
    usage: '.script',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const res = await fetch('https://api.github.com/repos/GlobalTechInfo/MEGA-MD');
            if (!res.ok)
                throw new خطأ('خطأ fetching repository data');
            const json = await res.json();
            let txt = `*乂  MEGA MDX  乂*\n\n`;
            txt += `✩  *الاسم* : ${json.name}\n`;
            txt += `✩  *Watchers* : ${json.watchers_count}\n`;
            txt += `✩  *الحجم* : ${(json.size / 1024).toFixed(2)} MB\n`;
            txt += `✩  *Last تم التحديث* : ${moment(json.updated_at).format('DD/MM/YY - HH:mm:ss')}\n`;
            txt += `✩  *URL* : ${json.html_url}\n`;
            txt += `✩  *Forks* : ${json.forks_count}\n`;
            txt += `✩  *Stars* : ${json.stargazers_count}\n\n`;
            txt += `💥 *MEGA MD*`;
            const imgPath = path.join(process.cwd(), 'assets/thumb.png');
            const imgBuffer = fs.readFileSync(imgPath);
            await sock.sendMessage(chatId, { image: imgBuffer, caption: txt }, { quoted: message });
        }
        catch (error) {
            console.error('خطأ in github command:', error);
            await sock.sendMessage(chatId, { text: '❌ خطأ fetching repository information.' }, { quoted: message });
        }
    }
};
