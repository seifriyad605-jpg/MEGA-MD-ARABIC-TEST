export default {
    command: 'tagall',
    aliases: ['everyone', 'all'],
    category: 'admin',
    description: 'Tag all group members with their usernames',
    usage: '.tagall',
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        try {
            const groupMetadata = await sock.groupMetadata(chatId);
            const participants = groupMetadata.participants;
            if (!participants || participants.length === 0) {
                await sock.sendMessage(chatId, {
                    text: 'لا participants found in the group.',
                    ...channelInfo
                }, { quoted: message });
                return;
            }
            let messageText = '🔊 *Hello Everyone:*\n\n';
            participants.forEach((participant) => {
                messageText += `@${participant.id.split('@')[0]}\n`;
            });
            await sock.sendMessage(chatId, {
                text: messageText,
                mentions: participants.map((p) => p.id),
                ...channelInfo
            });
        }
        catch (error) {
            console.error('خطأ in tagall command:', error);
            await sock.sendMessage(chatId, {
                text: 'فشل to tag all members.',
                ...channelInfo
            }, { quoted: message });
        }
    }
};
