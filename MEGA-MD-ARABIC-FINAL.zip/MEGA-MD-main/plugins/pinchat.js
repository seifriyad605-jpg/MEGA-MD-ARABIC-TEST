export default {
    command: 'pinchat',
    aliases: ['pin', 'unpin', 'unpinchat'],
    category: 'owner',
    description: 'Pin or unpin the current chat',
    usage: '.pinchat pin | .pinchat unpin',
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const rawText = (context.rawText || '').toLowerCase();
        const shouldPin = !rawText.startsWith('.unpin');
        try {
            await sock.chatModify({ pin: shouldPin }, chatId);
            await sock.sendMessage(chatId, {
                text: shouldPin ? `📌 *Chat pinned!*` : `📌 *Chat unpinned!*`,
                ...channelInfo
            }, { quoted: message });
        }
        catch (e) {
            console.error('[PINCHAT] خطأ:', e.message);
            await sock.sendMessage(chatId, {
                text: `❌ فشل to ${shouldPin ? 'pin' : 'unpin'} chat: ${e.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};
