import { setCommandReactState } from '../lib/reactions.js';
const MONGO_URL = process.env.MONGO_URL;
const POSTGRES_URL = process.env.POSTGRES_URL;
const MYSQL_URL = process.env.MYSQL_URL;
const SQLITE_URL = process.env.DB_URL;
const HAS_DB = !!(MONGO_URL || POSTGRES_URL || MYSQL_URL || SQLITE_URL);
export default {
    command: 'cmdreact',
    aliases: ['creact', 'commandreact'],
    category: 'owner',
    description: 'Toggle command reactions',
    usage: '.creact on/off',
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        if (!args[0] || !['on', 'off'].includes(args[0])) {
            await sock.sendMessage(chatId, {
                text: `*طريقة الاستخدام:*\n.creact on/off\n\nStorage: ${HAS_DB ? 'Database' : 'ملف System'}`,
                ...channelInfo
            }, { quoted: message });
            return;
        }
        if (args[0] === 'on') {
            await setCommandReactState(true);
            await sock.sendMessage(chatId, {
                text: `*✅ الأمر reactions enabled*\n\nStorage: ${HAS_DB ? 'Database' : 'ملف System'}`,
                ...channelInfo
            }, { quoted: message });
        }
        else if (args[0] === 'off') {
            await setCommandReactState(false);
            await sock.sendMessage(chatId, {
                text: `*❌ الأمر reactions disabled*\n\nStorage: ${HAS_DB ? 'Database' : 'ملف System'}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};
