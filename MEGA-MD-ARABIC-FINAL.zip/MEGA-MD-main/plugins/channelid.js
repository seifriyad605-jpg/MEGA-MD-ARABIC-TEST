export default {
    command: 'channelid',
    aliases: ['newsletterid'],
    category: 'general',
    description: 'Get the internal JID of a WhatsApp Channel',
    usage: '.channelid <url>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        let url = args[0] || "";
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (quoted) {
            url = quoted.conversation || quoted.extendedTextMessage?.text || url;
        }
        if (!url || !url.includes('whatsapp.com/channel/')) {
            return await sock.sendMessage(chatId, {
                text: 'من فضلك أرسل a valid WhatsApp Channel URL.\n\n*مثال:* .channelid https://whatsapp.com/channel/xxxxx'
            }, { quoted: message });
        }
        const code = url.split('/').pop();
        try {
            const metadata = await sock.newsletterMetadata("invite", code);
            const response = `
🆔 *JID:* ${metadata.id}
      `.trim();
            await sock.sendMessage(chatId, { text: response }, { quoted: message });
        }
        catch (err) {
            console.error('Channel ID خطأ:', err);
            await sock.sendMessage(chatId, {
                text: '❌ *فشل to resolve:* This channel might be private, deleted, or the link is invalid.'
            }, { quoted: message });
        }
    }
};
