import pkg from 'api-qasim';
const QasimAny = pkg;
export default {
    command: 'npmstalk',
    aliases: ['npmstlk'],
    category: 'stalk',
    description: 'Get details about an NPM package',
    usage: '.npmstalk <package-name>',
    async handler(sock, message, args, context) {
        const { chatId } = context;
        if (!args[0]) {
            return await sock.sendMessage(chatId, {
                text: `✳️ من فضلك أرسل an NPM package name.\n\nExample:\n.npmstalk axios`
            }, { quoted: message });
        }
        try {
            const res = await QasimAny.npmStalk(args[0]);
            if (!res || !res.result) {
                throw new خطأ('Package not found or API error.');
            }
            const data = res.result;
            const authorName = (typeof data.author === 'object') ? data.author.name : (data.author || 'Unknown');
            const versionCount = data.versions ? Object.keys(data.versions).length : 0;
            let te = `┌──「 *NPM PACKAGE INFO* 」\n`;
            te += `▢ *🔖الاسم:* ${data.name}\n`;
            te += `▢ *🔖Creator:* ${authorName}\n`;
            te += `▢ *👥الإجمالي Versions:* ${versionCount}\n`;
            te += `▢ *📌Description:* ${data.description || 'لا description'}\n`;
            te += `▢ *🧩Repository:* ${data.repository?.url || 'لا repository available'}\n`;
            te += `▢ *🌍Homepage:* ${data.homepage || 'لا homepage available'}\n`;
            te += `▢ *🏷️Latest:* ${data['dist-tags']?.latest || 'N/A'}\n`;
            te += `▢ *🔗الرابط:* https://npmjs.com/package/${data.name}\n`;
            te += `└────────────`;
            await sock.sendMessage(chatId, { text: te }, { quoted: message });
        }
        catch (error) {
            console.error('NPM Stalk خطأ:', error);
            await sock.sendMessage(chatId, { text: `✳️ خطأ: Package not found or API issue.` }, { quoted: message });
        }
    }
};
