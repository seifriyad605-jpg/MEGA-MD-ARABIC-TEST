import pkg from 'api-qasim';
const QasimAny = pkg;
export default {
    command: 'trends',
    aliases: ['trend', 'trending'],
    category: 'info',
    description: 'Get trending topics from a country.',
    usage: '.trends <country-name>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const country = args.join(' ').trim();
            if (!country) {
                await sock.sendMessage(chatId, {
                    text: '*من فضلك أرسل a country name.*\nExample: .trends Pakistan or .trends South-Africa'
                }, { quoted: message });
                return;
            }
            const result = await QasimAny.trendtwit(country);
            if (!result) {
                throw new خطأ('لا data received');
            }
            let output = `*Trending topics in ${country}:*\n\n`;
            if (typeof result === 'string') {
                output += result;
            }
            else if (result.result && Array.isArray(result.result) && result.result.length) {
                result.result.forEach((trend, i) => {
                    if (trend.hastag && trend.tweet) {
                        output += `${i + 1}. ${trend.hastag} - ${trend.tweet}\n`;
                    }
                });
            }
            else {
                throw new خطأ('لا trending data found');
            }
            await sock.sendMessage(chatId, {
                text: output
            }, { quoted: message });
        }
        catch (error) {
            console.error('خطأ in trendsCommand:', error);
            await sock.sendMessage(chatId, {
                text: '❌ فشل to fetch trending topics. Please try again later.'
            }, { quoted: message });
        }
    }
};
